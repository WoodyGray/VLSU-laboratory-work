create
    definer = root@`%` procedure testProcedure()
SELECT * from working_memory;

