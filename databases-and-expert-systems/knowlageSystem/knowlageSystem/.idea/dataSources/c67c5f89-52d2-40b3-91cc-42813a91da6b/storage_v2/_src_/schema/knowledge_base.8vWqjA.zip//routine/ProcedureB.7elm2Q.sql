create
    definer = root@`%` procedure ProcedureB(IN rule int, OUT flag int)
begin
    declare done_outer int default false;
    declare flag int default 1;
    declare fact_id int;

    declare fact_cursor cursor for
        select id_fact from facts_and_rules where id_rule = rule;

    declare continue handler for not found set done_outer = true;

    open fact_cursor;
    read_loop: loop
        fetch fact_cursor into fact_id;
        select 'factid', fact_id;
        if ((select count(*) from working_memory where id_fact = fact_id) <> 1) then
            set flag = 0;
            leave read_loop;
        end if;
    end loop;

end;

