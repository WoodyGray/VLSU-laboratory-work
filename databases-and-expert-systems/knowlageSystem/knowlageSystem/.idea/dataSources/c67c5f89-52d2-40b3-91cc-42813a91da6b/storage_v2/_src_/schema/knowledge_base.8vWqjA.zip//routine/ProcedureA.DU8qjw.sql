create
    definer = root@`%` procedure ProcedureA()
begin
    declare done_outer int default false;
    declare procedureBValue int;
    declare rule_id int;
    declare name varchar(100);


    declare fact_cursor cursor for
        select id, rule_name from rules;

    declare continue handler for not found set done_outer = true;

    open fact_cursor;
    read_loop: loop
        fetch fact_cursor into rule_id, name;
        call procedureB(rule_id, procedureBValue);
        SELECT 'procedureB', procedureBValue;
        if (procedureBValue = 1) then
            insert into working_memory(name, id_rule) value (name, rule_id);
        end if;

    end loop;

end;

